public class Register {
    int reader_num;
    String reader_name;
    String reader_password;
    int reader_count;

    public int getReader_num() {
        return reader_num;
    }

    public void setReader_num(int reader_num) {
        this.reader_num = reader_num;
    }

    public int getReader_count() {
        return reader_count;
    }

    public void setReader_count(int reader_count) {
        this.reader_count = reader_count;
    }

    String reader_idnum;
    String reader_phone;

    public String getReader_name() {
        return reader_name;
    }

    public void setReader_name(String reader_name) {
        this.reader_name = reader_name;
    }

    public String getReader_password() {
        return reader_password;
    }

    public void setReader_password(String reader_password) {
        this.reader_password = reader_password;
    }

    public String getReader_idnum() {
        return reader_idnum;
    }

    public void setReader_idnum(String reader_idnum) {
        this.reader_idnum = reader_idnum;
    }

    public String getReader_phone() {
        return reader_phone;
    }

    public void setReader_phone(String reader_phone) {
        this.reader_phone = reader_phone;
    }
}
